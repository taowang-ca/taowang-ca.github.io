import * as PIXI from "pixi.js";
import { MainView } from "~/client/gameViews/mainView";
import { GameUIData, GameStageInfo } from "~/client/types/UIDefinitions";
import { GameData } from "~/client/types/GameDataDefinitions";
import { SplashScreen } from "client/gameViews/SplashScreen";
import { EventBus } from "client/events/EventBus";
import { EVENT_CUSTOM, EvtDataUILayout } from "client/events/EventDefinitions";

export class Main {
    private static readonly DEFAULT_WIDTH = 400;
    private static readonly DEFAULT_HEIGHT = 900;
    private static readonly DEFAULT_BG_COLOR = 0xD3D3D3;
    private static readonly ASSETS_FOLDER = "./assets/";

    private app!: PIXI.Application;
    protected mainView!: MainView;
    protected splashScreen!: SplashScreen;

    constructor() {
        window.onload = (): void => {
            this.loadAssets();
        };
    }

    private loadAssets(): void {
        const loader = PIXI.Loader.shared;
        loader.add("bg.jpg", Main.ASSETS_FOLDER + "bg.jpg");
        loader.add("arts", Main.ASSETS_FOLDER + "spritesheet.json");
        loader.add("gameData", Main.ASSETS_FOLDER + "GameDataDefinition.json");
        loader.add("UIData1", Main.ASSETS_FOLDER + "GameUIDefinition01.json")
        loader.add("UIData2", Main.ASSETS_FOLDER + "GameUIDefinition02.json")

        loader.onComplete.once(() => {
            this.onAssetsLoaded();
        });
        
        loader.load();
    }

    private onAssetsLoaded(): void {
        const dataUI1: GameUIData = PIXI.Loader.shared.resources.UIData1.data;
        const dataUI2: GameUIData = PIXI.Loader.shared.resources.UIData2.data;
        if (dataUI1.stageInfo) this.createRenderer(dataUI1.stageInfo);

        EventBus.getInstance().addEventListener(EVENT_CUSTOM.setUILayout, this.onLayoutSelected, this);

        this.showSplashScreen(dataUI1, dataUI2);
    }

    private createRenderer(stageInfo: GameStageInfo): void {
        if (!stageInfo) return;

        const stageColor: number = (stageInfo.stageBgColor) ? Number(stageInfo.stageBgColor) : Main.DEFAULT_BG_COLOR;
        const w:number = stageInfo.gameWidth || Main.DEFAULT_WIDTH;
        const h:number = stageInfo.gameHeight || Main.DEFAULT_HEIGHT;

        this.app = new PIXI.Application({
            backgroundColor: stageColor,
            width: w,
            height: h,
        });

        document.getElementById("gameHolder")?.appendChild(this.app.view);

        this.app.renderer.resize(window.innerWidth, window.innerHeight);

        window.addEventListener("resize", this.onResize.bind(this));
    }

    private showSplashScreen(dataUI1: GameUIData, dataUI2: GameUIData): void {
        this.splashScreen = new SplashScreen(dataUI1, dataUI2);
        this.app.stage.addChild(this.splashScreen);
        this.onResize();
    }

    private hideSplashScreen(): void {
        this.app.stage.removeChild(this.splashScreen);
    }

    private loadGame(dataUI: GameUIData, resetGame: boolean): void {
        const dataGame: GameData = PIXI.Loader.shared.resources.gameData.data;

        this.mainView = new MainView(dataGame, dataUI, this.app.ticker, resetGame);
        this.app.stage.addChild(this.mainView);
        this.onResize();
    }
    
    private onLayoutSelected(evt: EvtDataUILayout): void {
        const dataUI: GameUIData = (evt.layoutIdx === 2) ?
            PIXI.Loader.shared.resources.UIData2.data : PIXI.Loader.shared.resources.UIData1.data;
        
        const stageColor: number = (dataUI.stageInfo.stageBgColor) ?
            Number(dataUI.stageInfo.stageBgColor) : Main.DEFAULT_BG_COLOR;
        this.app.renderer.backgroundColor = stageColor;

        this.hideSplashScreen();

        this.loadGame(dataUI, evt.resetGame);
    }

    private onResize(): void {
        if (!this.app) return;

        this.app.renderer.resize(window.innerWidth, window.innerHeight);

        this.scaleView(this.splashScreen);
        this.scaleView(this.mainView);
    }
    
    private scaleView(view: PIXI.DisplayObject): void {
        if (view) {
            const scale = window.innerHeight / Main.DEFAULT_HEIGHT;
            view.scale.y = scale;
            view.scale.x = scale;
            view.x = (window.innerWidth - Main.DEFAULT_WIDTH * scale) / 2;
        }
    }
}

new Main();

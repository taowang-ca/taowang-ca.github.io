import { Graphics, Sprite, Text } from "pixi.js"
import { CircleDefinition, RectangleDefinition, PiXiElement } from "~/client/types/ViewDefinition";
import { VisualElementType, IStringPropertyMap } from "~/client/types/UIDefinitions";
import { logCaughtError } from "~/client/services/Services";
import { setPropertyValue, setDeeperPropertyValue } from "~/client/utils/Generics";

export const getRectangle = (def: RectangleDefinition, radius?: number): Graphics | null => {
    if (!def.width || !def.height || typeof def.width !== "number" || typeof def.height !== "number") return null;

    try {
        const rect = new Graphics();

        if (def.lineStyle) rect.lineStyle(def.lineStyle.width || 1, def.lineStyle.color || 0x000000, def.lineStyle.alpha || 1);

        if (def.fillStyle) rect.beginFill(def.fillStyle.color || 0x000000, def.fillStyle.alpha || 1);

        if (radius) rect.drawRoundedRect(0, 0, def.width, def.height, radius); 
        else rect.drawRect(0, 0, def.width, def.height);

        if (def.fillStyle) rect.endFill();

        return rect;
    } catch (error) {
        logCaughtError(error, `ViewFactory - getRectangle - width:${def.width}, height:${def.height}`);
        return null;
    }
}

export const getRectangleByProperties = (properties: IStringPropertyMap): Graphics | null => {
    if (properties.hasOwnProperty("rectangleDef")) {
        return properties.hasOwnProperty("radius") && typeof properties.radius === "number" ?
                    getRectangle(properties.rectangleDef, properties.radius) :
                    getRectangle(properties.rectangleDef);
    }

    return null;
}

export const getCircle = (def: CircleDefinition): Graphics | null => {
    if (!def.radius || typeof def.radius !== "number") return null;

    try {
        const circle = new Graphics();

        if (def.lineStyle) circle.lineStyle(def.lineStyle.width || 1, def.lineStyle.color || 0x000000, def.lineStyle.alpha || 1);

        if (def.fillStyle) circle.beginFill(def.fillStyle.color || 0x000000, def.fillStyle.alpha || 1);

        circle.drawCircle(0, 0, def.radius); 

        if (def.fillStyle) circle.endFill();

        return circle;
    } catch (error) {
        logCaughtError(error, `ViewFactory - getCircle - radius:${def.radius}`);
        return null;
    }
}

export const getCircleByProperties = (properties: IStringPropertyMap): Graphics | null => {
    if (properties.hasOwnProperty("circleDef")) {
        return getCircle(properties.circleDef);
    }

    return null;
}

export const getSprite = (name: string): Sprite | null => {
    if (!name || name.length < 1) return null;

    try {
        return Sprite.from(name);
    } catch (error) {
        logCaughtError(error, `ViewFactory - getSprite - name:${name}`);
        return null;
    }
}

export const getSpriteByProperties = (properties: IStringPropertyMap): Sprite | null => {
    if (properties.hasOwnProperty("name")) {
        return getSprite(properties.name);
    }

    return null;
}

export const getLabel = (text: string, style: object = {}): Text | null => {
    if (!text) text = "";

    try {
        return new Text(text, style);
    } catch (error) {
        logCaughtError(error, `ViewFactory - getLabel - text:${text}`);
        return null;
    }
}

export const getLabelByProperties = (properties: IStringPropertyMap): Text | null => {
    if (properties.hasOwnProperty("text") && properties.hasOwnProperty("style")) {
        return getLabel(properties.text, properties.style);
    }

    return null;
}

/**
 * Game views get all PIXI elements from here.
 * It could be more type of PIXI elements are supported here,
 * but for the scale of the current game and limited time, I only added basic ones.
 * 
 * @param type 
 * @param parameters 
 * @param properties 
 */
export const getVisualElement = (type: VisualElementType,
                                parameters: IStringPropertyMap,
                                properties?: IStringPropertyMap): PiXiElement | null => {
    if (!parameters) return null;

    let element: PiXiElement | null;
    switch (type) {
        case VisualElementType.label:
            element = getLabelByProperties(parameters);
            break;

        case VisualElementType.sprite:
            element = getSpriteByProperties(parameters);
            break ;

        case VisualElementType.rectangle:
            element =  getRectangleByProperties(parameters);
            break;

        case VisualElementType.circle:
            element =  getCircleByProperties(parameters);
            break;

        default: return null;
            break;
    }

    if (element && properties) applyElementProperties(element, properties);

    return element;
}

/**
 * Apply properties to an element.
 * 
 * We use generic function "setPropertyValue" and "setDeeperPropertyValue"
 * to safely set values for an element's properties.
 * 
 * About the switch cases for "scale" and "anchor":
 * The value of "scale", "anchor", etc is an object like {x: 0, y: 0} instead of a string or number.
 * Normally use function "setPropertyValue" set "scale" and "anchor" is safe
 * unless applies invalid value like {x: 0} or {x: 0, z: 0} to them. 
 * Therefore we'd rather use function "setDeeperPropertyValue" to make it safer.
 * 
 * @param element 
 * @param properties 
 */
export const applyElementProperties = (element: PiXiElement, properties: IStringPropertyMap): void => {
    if (!element || !properties) return;
    
    try {
        for (const key in properties) {
            if (key) {
                switch (key) {
                    case "scale":
                        if ("scale" in element) {
                            setDeeperPropertyValue(element, "scale", "x", properties[key].x);
                            setDeeperPropertyValue(element, "scale", "y", properties[key].y);
                        } 
                        break;

                    case "anchor":
                        if ("anchor" in element) {
                            setDeeperPropertyValue(element, "anchor","x", properties[key].x);
                            setDeeperPropertyValue(element, "anchor","y", properties[key].y);
                        }
                        break;
                
                    case "style":
                        if ("style" in element) {
                            setDeeperPropertyValue(element, "style", "fill", properties[key].fill);
                        } 
                        break;
    
                    default:
                        setPropertyValue(element, key, properties[key]);
                        break;
                }
            }
        }
    } catch (error) {
        logCaughtError(error, `ViewFactory - applyElementProperties.`);
    }
}
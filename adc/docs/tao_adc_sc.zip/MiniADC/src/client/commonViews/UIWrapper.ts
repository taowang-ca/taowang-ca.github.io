/**
 * UIWrapper class is a container of VisualElementGroups.
 * Its duties are simply create a list of VisualElementGroups at the beginning, 
 * and pass the matched states to the right VisualElementGroups when the states of game changed.
 */
import { Container } from "pixi.js";
import { VisualElementGroupData, UIWrapperData } from "~/client/types/UIDefinitions";
import { VisualElementGroup } from "./VisualElementGroup";
import { logStrError } from "~/client/services/Services";
import { GameStateGroup } from "~/client/types/GameDataDefinitions";

export class UIWrapper extends Container {
    protected elementGroupDataList: Array<VisualElementGroupData>;
    protected elementGroupList: Array<VisualElementGroup> = [];

    constructor(data: UIWrapperData) {
        super();

        // Separate init data and init UI, so subclasses can alway insure to init data before init UI.
        this.initData(data);
        this.initUI();
    }
    
    /**
     * Called when game state has changed.
     * It will go through this.elementGroupDataList, fins the matched groupType, and passed the state group in.
     * @param stateGroupList 
     */
    public updateState(stateGroupList: Array<GameStateGroup>): void {
        stateGroupList.forEach(stateGroup => {
            const elementGroup: VisualElementGroup | undefined = this.getElementGroupByType(stateGroup.groupType);
            if (elementGroup) {
                elementGroup.updateState(stateGroup.states);
            }
        });
    }

    public getElementGroupById(id: string): VisualElementGroup | undefined {
        if (this.elementGroupList && this.elementGroupDataList && this.elementGroupDataList instanceof Array) {
            for (let i = 0; i < this.elementGroupDataList.length; i++) {
                if (this.elementGroupDataList[i].groupId === id &&
                   this.elementGroupList.length > i) return this.elementGroupList[i];
            }
        }
    }    
    
    public getElementGroupByType(type: string): VisualElementGroup | undefined {
        if (this.elementGroupList && this.elementGroupDataList && this.elementGroupDataList instanceof Array) {
            for (let i = 0; i < this.elementGroupDataList.length; i++) {
                if (this.elementGroupDataList[i].groupType === type &&
                   this.elementGroupList.length > i) return this.elementGroupList[i];
            }
        }
    }    
    
    protected initData(data: UIWrapperData): void {
        this.elementGroupDataList = data.gameUIGroups;
    }
        
    protected initUI(): void {
        if (!this.elementGroupDataList) return;
        if (!(this.elementGroupDataList instanceof Array)) return;

        // Create all VisualElementGroups.
        // We might need to drop some "bad" data from this.elementGroupDataList during the process,
        // so we use traditional "for" instead of "for each" here.
        for (let i = 0; i < this.elementGroupDataList.length; i++) {
            const elementGroupData: VisualElementGroupData = this.elementGroupDataList[i];
            if (this.isElementGroupDataValid(elementGroupData)) {
                const elementGroup: VisualElementGroup = new VisualElementGroup(elementGroupData);
                elementGroup.x = elementGroupData.x;
                elementGroup.y = elementGroupData.y;
                this.addChild(elementGroup);
                this.elementGroupList.push(elementGroup);
            } else { // We just log the issue here, drop the data and move on.
                const badData = this.elementGroupDataList.splice(i, 1);
                i--;
                if (badData && badData.length > 0)
                {
                    const id: string | undefined = badData.pop()?.groupId;
                    if (id) logStrError(`Can not create element group - ${id}`);
                } 
            }
        }
    }
    
    private isElementGroupDataValid(elementGroupData: VisualElementGroupData): boolean {
        return (elementGroupData &&
                elementGroupData.elementDataList &&
                elementGroupData.x !== undefined &&
                elementGroupData.y !== undefined);
    }
    
}
/**
 * VisualElementGroup is a container of PiXiElement.
 * It will create PiXiElements by data through a ViewFactory, 
 * and pass updated game states to them.
 * It also an interactive item that dispatches user click/touch action as a game level event.
 */
import { Container } from "pixi.js";
import { IVisualElementGroup } from "~/client/Interfaces/GenericUIInterface";
import {
    VisualElementGroupData,
    GameStateItem,
    VisualElementData,
    ResponseItem
    } from "~/client/types/UIDefinitions";
import { PiXiElement } from "~/client/types/ViewDefinition";
import { sortGameStateItem, matchSortedGameState } from "~/client/utils/DataUtils";
import { getVisualElement, applyElementProperties } from "~/client/factories/ViewFactory";
import { logStrError } from "~/client/services/Services";
import { EVENT_PIXI, clickOrPressUIEvt } from "~/client/events/EventDefinitions";
import { EventBus } from "~/client/events/EventBus";

export class VisualElementGroup extends Container implements IVisualElementGroup<Array<GameStateItem>> {
    protected elementDataList: Array<VisualElementData>;
    protected elementList: Array<PiXiElement> = [];

    constructor(protected groupData: VisualElementGroupData) {
        super();

        // Separate init data and init UI, so subclasses can alway insure to init data before init UI.
        this.initData(groupData);
        this.initUI();
        this.initEventListeners();
    }

    /**
     * Called when game state has changed.
     * It will go through this.elementDataList to find out which element should be effected,
     * then apply the changes to effected elements.
     * @param newState 
     */
    public updateState(newState: Array<GameStateItem>): void {
        // Sort GameStateItem for comparing later.
        const sortedState: Array<GameStateItem> = newState.sort(sortGameStateItem);    

        // We need the index of this.elementDataList for getting element in this.elementList,
        // so we use traditional "for" instead of "for each" here.
        for (let i = 0; i < this.elementDataList.length; i++) {
            const elementData: VisualElementData = this.elementDataList[i];
            const responses: Array<ResponseItem> = elementData.responseList;

            if (!responses || !(responses instanceof Array)) continue;
            
            // We need to use "break", so we have to use traditional "for" instead of "for each" here.
            for (let j = 0; j < responses.length; j++) {
                const response: ResponseItem = responses[j];
                if (matchSortedGameState(sortedState, response.conditions)) {
                    const element: PiXiElement = this.elementList[i];
                    if (element && response.responseProperties) applyElementProperties(element, response.responseProperties);
                    break;
                }
            }
        }
    }

    public getElementById(id: string): PiXiElement | undefined {
        if (this.elementList && this.elementDataList && this.elementDataList instanceof Array) {
            for (let i = 0; i < this.elementDataList.length; i++) {
                if (this.elementDataList[i].elementId === id &&
                   this.elementList.length > i) return this.elementList[i];
            }
        }
    }    
    
    /**
     * Init data for the class.
     * Do a response conditions sorting for each element data for future use. 
     * @param data 
     */
    protected initData(data: VisualElementGroupData): void {
        this.elementDataList = data.elementDataList;

        this.elementDataList.forEach(elementData => {
            if (elementData.responseList) {
                // Sort response conditions here once so we don't need to sort them every time when updateState got called.
                elementData.responseList.forEach(response => {
                    response.conditions.sort(sortGameStateItem);
                });
            }
            
        });
    }

    /**
     * Init all visual elements from this.elementDataList.
     * Subclasses should override this method to do any UI init work.
     */
    protected initUI(): void {
        if (!this.elementDataList) return;

        // Create all Elements.
        // We might need to drop some "bad" data from this.elementDataList during the process,
        // so we use traditional "for" instead of "for each" here.
        for (let i = 0; i < this.elementDataList.length; i++) {
            const elementData: VisualElementData = this.elementDataList[i];
            if (elementData.elementType && elementData.initParameters) {
                const element: PiXiElement | null =
                    getVisualElement(elementData.elementType, elementData.initParameters, elementData.initProperties || null);
                if (element) {
                    this.elementList.push(element);
                    this.addChild(element);
                } else {
                    // The visual element factory (getVisualElement) can't return a right element from the data it received.
                    // It might can't recognize the VisualElementType or some of the essential properties are missing.
                    // The cause could be the data from server is bad or the client has been updated to new version yet.
                    // We just log the issue here, drop the data and move on. 
                    const badData = this.elementDataList.splice(i, 1);
                    i--;
                    if (badData && badData.length > 0)
                    {
                        const type: string | undefined = badData.pop()?.elementType;
                        if (type) logStrError(`Can not create element type - ${type}`);
                    } 
                }
            }
            
        }
    }
    
    protected initEventListeners(): void {
        if (this.groupData.interactive) {
            this.interactive = true;

            this.addListener(EVENT_PIXI.clickOrPress, () => {
                EventBus.getInstance().dispatchEvent(clickOrPressUIEvt({ groupId: this.groupData.groupId }));
            });
        }
    }

}
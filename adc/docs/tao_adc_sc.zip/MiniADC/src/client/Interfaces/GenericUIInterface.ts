export interface IVisualElementGroup <S> {
    updateState(newState: S): void;
}

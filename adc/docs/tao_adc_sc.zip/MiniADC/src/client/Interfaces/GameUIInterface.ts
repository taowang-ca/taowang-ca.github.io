export interface IProgressIndicator {
    setProgress(value: number): void;
    setAmount(value: number): void;
}
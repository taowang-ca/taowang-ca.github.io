import { Text, Container } from "pixi.js";
import { getLabel } from "~/client/factories/ViewFactory";
import { GameUIData, VisualElementGroupData } from "~/client/types/UIDefinitions";
import { VisualElementGroup } from "~/client/commonViews/VisualElementGroup";
import { EVENT_PIXI, setUILayoutEvt } from "~/client/events/EventDefinitions";
import { EventBus } from "~/client/events/EventBus";
import { CheckBox } from "./CheckBox";

export class SplashScreen extends Container{
    private LABEL_STYLE = {
        fontFamily: ["Grandstander", "Arial"],
        fontSize: 30,
        fontWeight: 800,
        fill: 0xFFFFFF,
        align: "center",
        dropShadow: true,
        dropShadowDistance: 1
    };
    private GAME_NAME = "Mini Adventure Capitalist";
    private RESET_TEXT = "Reset game to a fresh start";

    private resetGameCheckBox: CheckBox;

    constructor(private dataUI1: GameUIData, private dataUI2: GameUIData) {
        super();

        this.initUI();
    }

    private initUI(): void {
        this.setGameLabel();
        this.setLayoutBtn(this.dataUI1, 36, 400, 1);
        this.setLayoutBtn(this.dataUI2, 40, 600, 2);
        this.setResetCheckBox();
    }

    private setGameLabel(): void {
        const gameLabel: Text = getLabel(this.GAME_NAME, this.LABEL_STYLE);
        gameLabel.x = 15;
        gameLabel.y = 200;
        this.addChild(gameLabel);
    }
    
    private setResetCheckBox(): void {
        this.resetGameCheckBox = new CheckBox(this.RESET_TEXT);
        this.resetGameCheckBox.x = 45;
        this.resetGameCheckBox.y = 800;
        this.addChild(this.resetGameCheckBox);

        this.resetGameCheckBox.interactive = true;
        this.resetGameCheckBox.buttonMode = true;
        this.resetGameCheckBox.addListener(EVENT_PIXI.clickOrPress, () => {
            this.switchReset();
        });
    }

    private setLayoutBtn(dataUI: GameUIData, x:number, y:number, idx:number) {
        const gameTitleData: VisualElementGroupData | undefined = this.getGameTitleUIData(dataUI);
        if (gameTitleData) {
            const layoutBtnData: VisualElementGroupData = {...gameTitleData};
            const layoutBtn: VisualElementGroup = new VisualElementGroup(layoutBtnData);
            layoutBtn.x = x;
            layoutBtn.y = y;
            layoutBtn.scale.set(0.8, 0.8);
            this.addChild(layoutBtn);
            layoutBtn.interactive = true;
            layoutBtn.buttonMode = true;
            layoutBtn.addListener(EVENT_PIXI.clickOrPress, () => {
                this.loadGameUI(idx);
            });
        }
    }
    
    private getGameTitleUIData(dataUI: GameUIData): VisualElementGroupData | undefined {
        if (!dataUI || !dataUI.wrapperGroups || !(dataUI.wrapperGroups instanceof Array)) return;

        for (let i = 0; i < dataUI.wrapperGroups.length; i++) {
            if (!dataUI.wrapperGroups[i].gameUIGroups ||
                !(dataUI.wrapperGroups[i].gameUIGroups instanceof Array)) continue;
            
            for (let j = 0; j < dataUI.wrapperGroups[i].gameUIGroups.length; j++) {
                if (dataUI.wrapperGroups[i].gameUIGroups[j].groupId === "gameTitle") {
                    return dataUI.wrapperGroups[i].gameUIGroups[j];
                }
            }
        }
    }

    private switchReset(): void {
        this.resetGameCheckBox.checked = !this.resetGameCheckBox.checked;
    }

    private loadGameUI(layoutIdx: number): void {
        const resetGame = this.resetGameCheckBox.checked;
        EventBus.getInstance().dispatchEvent(setUILayoutEvt({layoutIdx, resetGame}));
    }
}
import { Graphics } from "pixi.js";
import { getRectangle } from "~/client/factories/ViewFactory";
import { ProgressBarDefinition, ProgressAmountDefinition } from "~/client/types/UIDefinitions";
import { ProgressIndicator } from "./ProgressIndicator";

export class ProgressBar extends ProgressIndicator{
    private background: Graphics | null;
    private bar: Graphics | null;
    private barMask: Graphics | null;

    constructor(private barDef: ProgressBarDefinition, amountDef: ProgressAmountDefinition) {
        super(amountDef);

        this.initUI();
    }

    public setProgress(value: number): void {
        if (value > 1 || !this.bar || !this.barMask) return;
        
        if (value <= 0) {
            this.bar.visible = false;
        } else {
            this.barMask.scale.x = value;
            if (!this.bar.visible) this.bar.visible = true;
        }
    }

    protected initUI(): void {
        super.initUI();

        if (!this.barDef || !this.barDef.backgroundStyle || !this.barDef.barStyle) return;
        
        this.background = getRectangle(this.barDef.backgroundStyle, 8);
        if (this.background) this.addChild(this.background);

        this.bar = getRectangle(this.barDef.barStyle, 8);
        if (this.bar) {
            this.bar.x = this.barDef.barX;
            this.bar.y = this.barDef.barY;
            this.addChild(this.bar);
        }
        
        this.barMask = getRectangle(this.barDef.barStyle);
        if (this.barMask && this.bar) {
            this.barMask.x = this.bar.x;
            this.barMask.y = this.bar.y;
            this.addChild(this.barMask);
            this.bar.mask = this.barMask;
        } 
    }
}
import { Graphics } from "pixi.js";
import { CircleDefinition } from "~/client/types/ViewDefinition";
import { ProgressAmountDefinition } from "~/client/types/UIDefinitions";
import { ProgressIndicator } from "./ProgressIndicator";

export class ProgressCircle extends ProgressIndicator{
    private circle: Graphics | null;

    constructor(private circleDef: CircleDefinition, amountDef: ProgressAmountDefinition) {
        super(amountDef);

        this.initUI();
    }

    public setProgress(value: number): void {
        if (value > 1 || !this.circle) return;
        
        if (value <= 0 || value === 1) {
            this.circle.visible = false;
        } else {
            this.circle.clear();
            const fillColor = this.circleDef.fillStyle.color || 0x1099BB;
            const fillAlpha = this.circleDef.fillStyle.alpha || 0.5;
            this.circle.beginFill(fillColor, fillAlpha);
            this.circle.arc(0, 0, this.circleDef.radius, Math.PI * 2 * value - Math.PI * .5, Math.PI * 2 - Math.PI * .5);
            this.circle.lineTo(0, 0);
            this.circle.endFill();
            if (!this.circle.visible) this.circle.visible = true;
        }
    }

    protected initUI(): void {
        super.initUI();

        if (!this.circleDef) return;

        this.circle = new Graphics();
        this.circle.position.set(this.circleDef.radius, this.circleDef.radius);
        this.addChild(this.circle);
    }
}
import { Text, Container, Graphics } from "pixi.js";
import { getLabel } from "~/client/factories/ViewFactory";

export class CheckBox extends Container{
    private LABEL_STYLE = {
        fontFamily: ["Grandstander", "Arial"],
        fontSize: 20,
        fontWeight: 500,
        fill: 0xFFFFFF,
        align: "center"
    };

    private _checked: boolean = false;

    private box: Graphics;
    private boxMark: Graphics;
    private label: Text;

    constructor(private _text: string = "") {
        super();

        this.initUI();
    }

    public get checked(): boolean {
        return this._checked;
    }

    public set checked(value: boolean) {
        if (value !== this._checked) {
            this._checked = value;
            this.boxMark.visible = value;
        }
    }

    public get text(): string {
        return this._text;
    }

    public set text(value: string) {
        if (value !== this._text) {
            this._text = value;
            if (this.label) this.label.text = value;
        }
    }

    private initUI(): void {
        this.setBox();
        this.setLabel();
    }

    private setBox(): void {
        this.box = new Graphics();
        this.box.lineStyle(3, 0xFFFFFF);
        this.box.beginFill(0x2A3744);
        this.box.drawRoundedRect(0, 0, 28, 28, 5);
        this.box.endFill();
        this.addChild(this.box);

        this.boxMark = new Graphics();
        this.boxMark.beginFill(0xFFFFFF);
        this.boxMark.drawRect(6, 6, 16, 16);
        this.boxMark.endFill();
        this.boxMark.visible = false;
        this.addChild(this.boxMark);
    }
    
    private setLabel(): void {
        this.label = getLabel(this._text, this.LABEL_STYLE);
        this.label.x = 33;
        this.addChild(this.label);
    }
}
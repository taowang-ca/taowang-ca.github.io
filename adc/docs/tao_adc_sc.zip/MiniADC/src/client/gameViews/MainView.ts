import { Container, Text, Ticker, DisplayObject } from "pixi.js";
import {
    UIWrapperData,
    WrapperType,
    GameUIData,
    ProgressIndicatorType,
    ProgressBarDefinition
    } from "~/client/types/UIDefinitions";
import { logStrError } from "~/client/services/Services";
import { UIWrapper } from "~/client/commonViews/UIWrapper";
import {
    GameData,
    InvestmentType,
    ProducingConditions,
    BusinessData,
    BusinessDataUI,
    BasicConditions,
    GameStateGroup
    } from "~/client/types/GameDataDefinitions";
import { sortBusinessByCost, applyBusinessDataToWrapper } from "~/client/utils/DataUtils";
import {
    calculateCapitalAmount,
    getBusinessDataById,
    finishProducing,
    startProducing,
    takeAction,
    getBusinessIdxById
    } from "~/client/services/GameController";
import { EventBus } from "~/client/events/EventBus";
import {
    EVENT_CUSTOM,
    EvtDataResumeProducing,
    EvtDataClickOrPressUI,
    EvtDataInvestmentDone,
    EvtDataBusinessID
    } from "~/client/events/EventDefinitions";
import { PiXiElement, CircleDefinition } from "~/client/types/ViewDefinition";
import { easyReadNumber } from "~/client/utils/StringUtils";
import { VisualElementGroup } from "~/client/commonViews/VisualElementGroup";
import { getBusinessState, setBusinessState, resetGameData } from "~/client/services/IOController";
import { ProgressBar } from "./ProgressBar";
import { gameStateList } from "~/client/constants/GameConstants";
import { ProgressCircle } from "./ProgressCircle";
import { IProgressIndicator } from "~/client/Interfaces/GameUIInterface";

export class MainView extends Container {
    private businessList: Array<BusinessData>;
    private businessWrappers: Array<UIWrapper> = [];
    private wrappersDataList: Array<UIWrapperData>;
    private wrappers: Array<UIWrapper> = [];
    private progressIndicators: Array<IProgressIndicator> = [];

    constructor(private gameData: GameData,
                private theUIData: GameUIData,
                private ticker: Ticker,
                resetGame: boolean = false) {
        super();

        // Separate init methods, so subclasses can alway insure to call them in order.
        this.initData(gameData, theUIData, resetGame);
        this.initUI();
        this.initEventListeners();
        this.initGame();
    }

    protected initData(dataGame: GameData, dataUI: GameUIData, resetGame: boolean): void {
        if (resetGame) resetGameData();
        
        if (!dataGame || !dataGame.BusinessList) return;
        if (!dataUI || !dataUI.wrapperGroups) return;

        const businessDataUI: BusinessDataUI = {timerId: -1,
                                                producingStartTime: -1,
                                                businessStateListIdx: -1,
                                                managerStateListIdx: -1,
                                                updateStateListIdx: -1 };
        this.businessList = dataGame.BusinessList.map(
                            (business) => {return {...business, ...businessDataUI}});
        this.businessList.sort(sortBusinessByCost);

        this.wrappersDataList = dataUI.wrapperGroups;
    }
    
    protected initUI(): void {
        if (!this.wrappersDataList) return;
        if (!(this.wrappersDataList instanceof Array)) return;
        
        // Create all wrappers.
        // We might need to drop some "bad" data from this.wrappersDataList during the process,
        // so we use traditional "for" instead of "for each" here.
        for (let i = 0; i < this.wrappersDataList.length; i++) {
            const wrapperData: UIWrapperData = this.wrappersDataList[i];
            if (this.isWrapperDataValid(wrapperData)) {
                switch (wrapperData.wrapperType) {
                    case WrapperType.listItem:
                        this.initItemTypeWrapper(wrapperData);
                        break;
                
                    case WrapperType.fixedItem:
                        this.setupWrapper(wrapperData);
                        break;
                    
                    default:
                        break;
                }
            } else { // We just log the issue here, drop the data and move on.
                const badData = this.wrappersDataList.splice(i, 1);
                i--;
                if (badData && badData.length > 0)
                {
                    const id: string | undefined = badData.pop()?.wrapperId;
                    if (id) logStrError(`Can not create element group - ${id}`);
                } 
            }
        }
    }
    
    protected initEventListeners(): void {
        EventBus.getInstance().addEventListener(EVENT_CUSTOM.clickOrPressUI, this.clickOrPressUI, this);
        EventBus.getInstance().addEventListener(EVENT_CUSTOM.capitalUpdated, this.capitalUpdated, this);
        EventBus.getInstance().addEventListener(EVENT_CUSTOM.investmentDone, this.investmentDone, this);
        EventBus.getInstance().addEventListener(EVENT_CUSTOM.startProducing, this.producingStarted, this);
        EventBus.getInstance().addEventListener(EVENT_CUSTOM.resumeProducing, this.producingResumed, this);
        EventBus.getInstance().addEventListener(EVENT_CUSTOM.finishProducing, this.producingFinished, this);
    }

    private initGame(): void {
        calculateCapitalAmount(this.gameData.initialCapital, this.businessList);

        this.businessList.forEach(business => {
            this.updateProgressBarTitle(business.businessId);
        });

        this.ticker.add(() => { this.updateProgress() });
    }
    
    private updateProgress(): void {
        for (let i = 0; i < this.businessList.length; i++) {
            const business = this.businessList[i];
            let progress: number = -1;
            if (business.producingStartTime > 0) {
                progress = (new Date().getTime() - business.producingStartTime) / (business.productionCycle * 1000);
            }
            this.progressIndicators[i].setProgress(progress);
        }
    }    

    private clickOrPressUI(evt: EvtDataClickOrPressUI): void {
        if (!evt || !evt.groupId) return;

        const tempArray = evt.groupId.split(".");
        if (tempArray.length > 1) {
            const businessID = tempArray[0];
            const investmentType = tempArray[1];
            takeAction(businessID, investmentType, this.businessList);
        }
    }

    private capitalUpdated(evt: number): void {
        // Update game title bar
        const element: PiXiElement | undefined = this.getElementById("fixedGroups", "gameTitle", "titleLabel");
        if (element && element instanceof Text) {
            element.text = "$" + easyReadNumber(evt);
        }

        // Notify other UIs a state change.
        this.updateBusinessState(evt);
    }

    /**
     * If the states for the whole business haven't change, do nothing, otherwise pass the states in to the wrapper.
     * The all kinds of "StateIdx"s here map to gameStateList in GameConstants.
     * @param business 
     */
    private updateBusinessState(newCapital: number): void {
        for (let i = 0; i < this.businessList.length; i++) {
            const business = this.businessList[i];
            
            if (this.businessWrappers.length <= i) break;
            
            const wrapper: UIWrapper = this.businessWrappers[i];
            
            let stateGroupList: Array<GameStateGroup> = [];
            let newStateIdx: number;
            let oldStateValue: number;
            let businessStateValue: number = getBusinessState(business.businessId, InvestmentType.business);
            if (businessStateValue === BasicConditions.acquired) {
                const produceStateValue: number = getBusinessState(business.businessId, InvestmentType.produce);
                newStateIdx = (produceStateValue === ProducingConditions.active) ? 8 : 9;
                if (business.businessStateListIdx !== newStateIdx) {
                    business.businessStateListIdx = newStateIdx;
                    stateGroupList.push({ groupType: InvestmentType.business, states: gameStateList[newStateIdx] });
                }

                oldStateValue = getBusinessState(business.businessId, InvestmentType.manager);
                const managerStateValue: number = (oldStateValue === BasicConditions.acquired) ? oldStateValue :
                                                  (newCapital >= business.managerWage) ?
                                                  BasicConditions.affordable : BasicConditions.unaffordable;
                if (oldStateValue !== managerStateValue) setBusinessState(business.businessId, InvestmentType.manager, managerStateValue);
                newStateIdx = (managerStateValue === BasicConditions.unaffordable) ? 2 :
                              (managerStateValue === BasicConditions.affordable) ? 3 : 4;
                if (business.managerStateListIdx !== newStateIdx) {
                    business.managerStateListIdx = newStateIdx;
                    stateGroupList.push({ groupType: InvestmentType.manager, states: gameStateList[newStateIdx] });
                }
                
                oldStateValue = getBusinessState(business.businessId, InvestmentType.upgrade);
                const upgradeStateValue: number = (oldStateValue === BasicConditions.acquired) ? oldStateValue :
                                                  (newCapital >= business.upgradeCost) ?
                                                  BasicConditions.affordable : BasicConditions.unaffordable;
                if (oldStateValue !== managerStateValue) setBusinessState(business.businessId, InvestmentType.upgrade, upgradeStateValue);
                newStateIdx = (upgradeStateValue === BasicConditions.unaffordable) ? 5 :
                              (upgradeStateValue === BasicConditions.affordable) ? 6 : 7;
                if (business.updateStateListIdx !== newStateIdx) {
                    business.updateStateListIdx = newStateIdx;
                    stateGroupList.push({ groupType: InvestmentType.upgrade, states: gameStateList[newStateIdx] });
                }
            } else {
                oldStateValue = businessStateValue;
                businessStateValue = (newCapital >= business.acquireCost) ? BasicConditions.affordable : BasicConditions.unaffordable;
                if (oldStateValue !== businessStateValue) setBusinessState(business.businessId, InvestmentType.business, businessStateValue);

                newStateIdx = (businessStateValue === BasicConditions.unaffordable) ? 0 : 1;
                if (business.businessStateListIdx !== newStateIdx) {
                    business.businessStateListIdx = newStateIdx;
                    stateGroupList.push({ groupType: InvestmentType.business, states: gameStateList[newStateIdx] });

                    business.managerStateListIdx = newStateIdx;
                    stateGroupList.push({ groupType: InvestmentType.manager, states: gameStateList[newStateIdx] });

                    business.updateStateListIdx = newStateIdx;
                    stateGroupList.push({ groupType: InvestmentType.upgrade, states: gameStateList[newStateIdx] });
                }
            }

            if (stateGroupList.length > 0) wrapper.updateState(stateGroupList);
        }
    }

    private investmentDone(evt: EvtDataInvestmentDone): void {
        // Notify progress bar.
        if (evt.investmentType === InvestmentType.upgrade) {
            this.updateProgressBarTitle(evt.businessId);
        }    

        // Check if it needs to start producing (Yes if it's not in a manual producing cycle)
        if (evt.investmentType === InvestmentType.manager) {
            if (getBusinessState(evt.businessId, InvestmentType.produce) !== ProducingConditions.active) {
                const business: BusinessData | undefined = getBusinessDataById(evt.businessId, this.businessList);
                if (business) {
                    startProducing(business.businessId);
                }
            }
        }
    }
    
    private updateProduceState(business: BusinessData, stateValue: number): void {
        const idx: number = getBusinessIdxById(business.businessId,this.businessList);
        if (idx >= 0 && idx < this.businessWrappers.length)
        {
            const newStateIdx = (stateValue === ProducingConditions.active) ? 8 : 9;
            business.businessStateListIdx = newStateIdx;

            const stateGroupList: Array<GameStateGroup> = [];
            stateGroupList.push({ groupType: InvestmentType.business, states: gameStateList[newStateIdx] });

            const wrapper: UIWrapper = this.businessWrappers[idx];
            wrapper.updateState(stateGroupList);
        }
    }    

    private producingStarted(evt: EvtDataBusinessID): void {
        if (!evt.businessId) return;

        const business: BusinessData | undefined = getBusinessDataById(evt.businessId, this.businessList);
        if (!business) return;

        this.updateProduceState(business, ProducingConditions.active);

        this.setProducingCycle(business, 0, business.productionCycle * 1000);
    }
    
    private producingResumed(evt: EvtDataResumeProducing): void {
        if (!evt.businessId) return;

        const business: BusinessData | undefined = getBusinessDataById(evt.businessId, this.businessList);
        if (!business) return;

        this.updateProduceState(business, ProducingConditions.active);

        this.setProducingCycle(business, evt.progress, business.productionCycle * 1000 - evt.progress);
    }

    private producingFinished(evt: EvtDataBusinessID): void {
        if (!evt.businessId) return;
        
        const business: BusinessData | undefined = getBusinessDataById(evt.businessId, this.businessList);
        if (!business) return;

        this.updateProduceState(business, ProducingConditions.idle);

        // check to see if it needs to start a producing cycle. (Yes when a manager is hired.)
        if (getBusinessState(business.businessId, InvestmentType.manager) === BasicConditions.acquired) {
            startProducing(business.businessId);
        }
    }

    private setProducingCycle(business: BusinessData, passedTime: number, duration: number): void {
        if (!business) return;

        // Set the producing start time for the progress bar.
        business.producingStartTime = new Date().getTime() - passedTime;

        // Start a timer
        business.timerId = window.setTimeout(() => { this.producingTimeUp(business); }, duration);
    }

    /**
     * This is a Timer call back. Called when one producing cycle is done.
     * @param business 
     */
    private producingTimeUp(business: BusinessData): void {
        if (!business) return;

        // Clear the producing start time for the progress bar.
        business.producingStartTime = -1;

        finishProducing(business.businessId, business.profitPerCycle, business.upgradeProfitRate);
    }    

    private isWrapperDataValid(wrapperData: UIWrapperData): boolean {
        return (wrapperData &&
                wrapperData.gameUIGroups &&
                wrapperData.wrapperType !== undefined &&
                wrapperData.x !== undefined &&
                wrapperData.y !== undefined);
    }
    
    private getWrapperById(id: string): UIWrapper | undefined {
        if (this.wrappers && this.wrappersDataList && this.wrappersDataList instanceof Array) {
            for (let i = 0; i < this.wrappersDataList.length; i++) {
                if (this.wrappersDataList[i].wrapperId === id &&
                   this.wrappers.length > i) return this.wrappers[i];
            }
        }
    }

    private getElementById(wrapperId: string, groupId: string, elementId: string): PiXiElement | undefined {
        const wrapper: UIWrapper | undefined = this.getWrapperById(wrapperId);
        if (wrapper) {
            const group: VisualElementGroup | undefined = wrapper.getElementGroupById(groupId);
            if (group) {
                const element: PiXiElement | undefined = group.getElementById(elementId);
                return element;
            }
        }
    }

    private setupWrapper(wrapperData: UIWrapperData): UIWrapper {
        const wrapper: UIWrapper = new UIWrapper(wrapperData);
        wrapper.x = wrapperData.x;
        wrapper.y = wrapperData.y;
        this.addChild(wrapper);
        this.wrappers.push(wrapper);
        return wrapper;
    }

    private initItemTypeWrapper(wrapperData: UIWrapperData): void {
        // const initY = wrapperData.y;
        let offsetY = wrapperData.y;

        this.businessList.forEach(business => {
            const clonedWrapperData = {...wrapperData};
            applyBusinessDataToWrapper(clonedWrapperData, business);
            const wrapper: UIWrapper = this.setupWrapper(clonedWrapperData);
            wrapper.y = offsetY;
            offsetY += wrapperData.height;
            this.injectProgressBar(wrapper, business.profitPerCycle);
            this.businessWrappers.push(wrapper);
        });
    } 
    
    private injectProgressBar(wrapper: UIWrapper, profit: number): void {
        if (!this.theUIData.progressIndicator) return;

        let progressIndicator: IProgressIndicator;
        if (this.theUIData.progressIndicator.type === ProgressIndicatorType.bar) {
            const def: ProgressBarDefinition = this.theUIData.progressIndicator.indicatorDef as ProgressBarDefinition;
            progressIndicator = new ProgressBar(def, this.theUIData.progressIndicator.amountDef);
        } else if (this.theUIData.progressIndicator.type === ProgressIndicatorType.circle) {
            const def: CircleDefinition = this.theUIData.progressIndicator.indicatorDef as CircleDefinition;
            progressIndicator = new ProgressCircle(def, this.theUIData.progressIndicator.amountDef);
        } 
        
        if (progressIndicator) {
            progressIndicator.setAmount(profit);
            if (progressIndicator instanceof DisplayObject) {
                progressIndicator.x = this.theUIData.progressIndicator.x;
                progressIndicator.y = this.theUIData.progressIndicator.y;
                wrapper.addChild(progressIndicator as DisplayObject);
            } 
            this.progressIndicators.push(progressIndicator);
        }
    }
    
    private updateProgressBarTitle(businessId: string): void {
        if (getBusinessState(businessId, InvestmentType.upgrade) === BasicConditions.acquired) {
            const idx: number = getBusinessIdxById(businessId, this.businessList);
            if (idx >= 0 && this.progressIndicators.length > idx) {
                const business: BusinessData = this.businessList[idx];
                this.progressIndicators[idx].setAmount(business.profitPerCycle * business.upgradeProfitRate);
            }
        } 
    }
}
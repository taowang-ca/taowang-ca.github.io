import { IProgressIndicator } from "~/client/Interfaces/GameUIInterface";
import { Text, Container } from "pixi.js";
import { getLabel } from "~/client/factories/ViewFactory";
import { easyReadNumber } from "~/client/utils/StringUtils"
import { ProgressAmountDefinition } from "~/client/types/UIDefinitions";

export abstract class ProgressIndicator extends Container implements IProgressIndicator{
    protected amountLabel: Text | null;

    constructor(protected amountDef: ProgressAmountDefinition) {
        super();
    }

    /**
     * Set Progress UI.
     * To be implemented by sub-classes.
     * @param value 
     */
    public abstract setProgress(value: number): void;

    /**
     * Set value for the amountLabel.
     * @param value 
     */
    public setAmount(value: number): void {
        const title = (this.amountDef.title) ? this.amountDef.title : "";
        if (this.amountLabel) this.amountLabel.text = easyReadNumber(value);
    }

    protected initUI(): void {
        if (this.amountDef) {
            this.amountLabel = getLabel("", this.amountDef.textStyle);
            if (this.amountLabel) {
                this.amountLabel.anchor.set(.5, .5);
                this.amountLabel.x = this.amountDef.x;
                this.amountLabel.y = this.amountDef.y;
                this.addChild(this.amountLabel);
            } 
        }
    }
}
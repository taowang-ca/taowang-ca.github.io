import { BusinessBasicData, BasicConditions, ProducingConditions, BusinessData } from "~/client/types/GameDataDefinitions";
import {
    getProducingStartTime,
    getBusinessState,
    getProducingEnd,
    setBusinessIncome,
    setProducingStartTime,
    getCapitalAmount,
    isTheFirstRun,
    spend,
    setBusinessState,
    initCapital
    } from "./IOController";
import { EventBus } from "~/client/events/EventBus";
import { 
    resumeProducingEvt,
    EvtDataResumeProducing,
    investmentDoneEvt,
    startProducingEvt,
    finishProducingEvt,
    capitalUpdatedEvt
    } from "~/client/events/EventDefinitions";
import { InvestmentType } from "~/client/types/GameDataDefinitions";

const calculateIncome = (businessData: BusinessBasicData, cycles: number): number => {
    const rate = (getBusinessState(businessData.businessId, InvestmentType.upgrade) === BasicConditions.acquired) ?
                 businessData.upgradeProfitRate : 1;
    return businessData.profitPerCycle * cycles * rate;
}

const getBusinessIdleIncome = (businessData: BusinessBasicData): number => {
    if (!businessData || !businessData.businessId) return 0;

    // Haven't buy the business yet.
    if (getBusinessState(businessData.businessId, InvestmentType.business) !== BasicConditions.acquired) return 0;

    const lastStartTime: number = getProducingStartTime(businessData.businessId);
    
    if (lastStartTime <= 0) return 0; // Never start producing.

    let newIncome = 0;
    const nowTime: number = new Date().getTime();
    const pastedStartTime = (nowTime - lastStartTime) / 1000;
    const pastTimeInCurrentCycle = pastedStartTime % businessData.productionCycle;
    if (getBusinessState(businessData.businessId, InvestmentType.manager) === BasicConditions.acquired) { // Managed business.
        // Calculate passed producing cycles while idle.
        const passedCycles = Math.floor(pastedStartTime / businessData.productionCycle);

        if (passedCycles > 0) {
            // got income for ths producing cycles.
            newIncome = calculateIncome(businessData, passedCycles);

            // Store the new income, AND set the producing end time to a right value.
            setBusinessIncome(businessData.businessId, newIncome, lastStartTime + businessData.productionCycle * passedCycles);

            // Set the producing start time to a right value.
            setProducingStartTime(businessData.businessId, lastStartTime + businessData.productionCycle * passedCycles + 1);
        }

        // Resume the producing.
        resumeProducing(businessData.businessId ,pastTimeInCurrentCycle * 1000);
    } else { // Un-managed business.
        const lastEndTime: number = getProducingEnd(businessData.businessId);
        if (lastEndTime < lastStartTime) { // The game closed inside the producing cycle.
            if (pastedStartTime < businessData.productionCycle) {
                // No income durning the idle.
                newIncome = 0;

                // Need to resume the producing.
                resumeProducing(businessData.businessId ,pastTimeInCurrentCycle * 1000);
            } else {
                // got income for one producing cycle, but no producing resume.
                newIncome = calculateIncome(businessData, 1);
                
                setBusinessState(businessData.businessId, InvestmentType.produce, ProducingConditions.idle);

                // Store the new income, AND set the producing end time to a right value.
                setBusinessIncome(businessData.businessId, newIncome, lastStartTime + businessData.productionCycle);
            }
        } else { // The game closed outside the producing cycle. No income durning the idle.
            newIncome = 0;
        }
    }

    return newIncome;
} 

/**
 * 
 * @param businessId 
 * @param progress - Milliseconds.
 */
const resumeProducing = (businessId: string, progress: number): void => {
    const resumeEvtData: EvtDataResumeProducing = { businessId, progress };
    EventBus.getInstance().dispatchEvent(resumeProducingEvt(resumeEvtData));
}

const spendOnBusiness = (businessId: string, investmentType: string, cost: number): boolean => {
    let capitalAmount: number = getCapitalAmount();
    if (cost <= capitalAmount) {
        setBusinessState(businessId, investmentType, BasicConditions.acquired);

        spend(cost);
        
        EventBus.getInstance().dispatchEvent(investmentDoneEvt({ businessId, investmentType }));
        return true;
    }

    return false;
}

const buyBusiness = (businessData: BusinessBasicData): boolean => {
    if (!businessData || !businessData.businessId || businessData.acquireCost === undefined) return false;

    return spendOnBusiness(businessData.businessId, InvestmentType.business, businessData.acquireCost);
}

const upgradeBusiness = (businessData: BusinessBasicData): boolean => {
    if (!businessData || !businessData.businessId || businessData.upgradeCost === undefined) return false;

    return spendOnBusiness(businessData.businessId, InvestmentType.upgrade, businessData.upgradeCost);
}

const hireManager = (businessData: BusinessBasicData): boolean => {
    if (!businessData || !businessData.businessId || businessData.managerWage === undefined) return false;

    return spendOnBusiness(businessData.businessId, InvestmentType.manager, businessData.managerWage);
}

export const getBusinessIdxById = (businessId: string, businessList: Array<BusinessData>): number => {
    if (!businessId || !businessList || !(businessList instanceof Array)) return -1;

    for (let i = 0; i < businessList.length; i++) {
        if (businessId === businessList[i].businessId) return i;
    }

    return -1;
}

export const getBusinessDataById = (businessId: string, businessList: Array<BusinessData>): BusinessData | undefined => {
    if (!businessId || !businessList || !(businessList instanceof Array)) return;

    for (let i = 0; i < businessList.length; i++) {
        if (businessId === businessList[i].businessId) return businessList[i];
    }
}

export const takeAction = (businessId: string, investmentType: string, businessList: Array<BusinessData>): void => {
    if (!businessList || !(businessList instanceof Array)) return;

    const investmentState: number = getBusinessState(businessId, investmentType);
    const business: BusinessBasicData | undefined = getBusinessDataById(businessId, businessList);
    if (business) {
        switch (investmentType) {
            case InvestmentType.business:
                if (investmentState === BasicConditions.acquired) {
                    const managerState: number = getBusinessState(businessId, InvestmentType.manager);
                    if (managerState !== BasicConditions.acquired) startProducing(business.businessId);
                } else {
                    buyBusiness(business);
                }
                break;
        
            case InvestmentType.manager:
                if (investmentState !== BasicConditions.acquired) hireManager(business);
                break;
    
            case InvestmentType.upgrade:
                if (investmentState !== BasicConditions.acquired) upgradeBusiness(business);
                break;
    
            default:
                break;
        }
    }
}

/**
 * Could be called by "takeAction" (produce manually) or called outside by manager timer (produce automatically).
 * @param businessId 
 * @param productionCycle 
 */
export const startProducing = (businessId: string): void => {
    if (getBusinessState(businessId, InvestmentType.business) !== BasicConditions.acquired) return;

    if (getBusinessState(businessId, InvestmentType.produce) === ProducingConditions.active) return;

    setBusinessState(businessId, InvestmentType.produce, ProducingConditions.active);
    
    setProducingStartTime(businessId, new Date().getTime());

    EventBus.getInstance().dispatchEvent(startProducingEvt({ businessId }));
}

/**
 * Always get called by a timer's callback.
 * @param businessId 
 * @param profitPerCycle 
 * @param upgradeProfitRate 
 */
export const finishProducing = (businessId: string, profitPerCycle: number, upgradeProfitRate: number): void => {
    const profit:number = (getBusinessState(businessId, InvestmentType.upgrade) === BasicConditions.acquired) ?
                          profitPerCycle * upgradeProfitRate : profitPerCycle;
    
    setBusinessIncome(businessId, profit);

    setBusinessState(businessId, InvestmentType.produce, ProducingConditions.idle);

    EventBus.getInstance().dispatchEvent(finishProducingEvt({ businessId }));
}

/**
 * Should only be called when game just loaded.
 * It will calculate all businesses' income during idle,
 * add them into last saved capital then save the new capital.
 * Meanwhile, it will also notify managed business to resume their producing.
 * @param initialCapital 
 * @param businessList 
 */
export const calculateCapitalAmount = (initialCapital: number, businessList: Array<BusinessBasicData>): void => {
    if (!businessList || !(businessList instanceof Array)) return;

    
    if (isTheFirstRun()) {
        initBusinessStates(businessList, initialCapital);
        initCapital(initialCapital);

        
    } else {
        if (getCapitalAmount() < 0) {
            initBusinessStates(businessList, initialCapital);
            initCapital(initialCapital);
        } 

        initBusinessStates(businessList, getCapitalAmount());

        EventBus.getInstance().dispatchEvent(capitalUpdatedEvt(getCapitalAmount()));

        businessList.forEach(business => getBusinessIdleIncome(business));
    }
}

const initBusinessStates = (businessList: Array<BusinessBasicData>, capital: number): void => {
    let newState: number;
    businessList.forEach(business => {
        if (getBusinessState(business.businessId, InvestmentType.business) < 0) {
            newState = (business.acquireCost > capital) ? BasicConditions.unaffordable : BasicConditions.affordable;
            setBusinessState(business.businessId, InvestmentType.business, newState);
        }
        
        if (getBusinessState(business.businessId, InvestmentType.produce) < 0) {
            setBusinessState(business.businessId, InvestmentType.produce, ProducingConditions.idle);
        }
        
        if (getBusinessState(business.businessId, InvestmentType.manager) < 0) {
            newState = (business.managerWage > capital) ? BasicConditions.unaffordable : BasicConditions.affordable;
            setBusinessState(business.businessId, InvestmentType.manager, newState);
        }
        
        if (getBusinessState(business.businessId, InvestmentType.upgrade) < 0) {
            newState = (business.upgradeCost > capital) ? BasicConditions.unaffordable : BasicConditions.affordable;
            setBusinessState(business.businessId, InvestmentType.upgrade, newState);
        }
    });
    
}

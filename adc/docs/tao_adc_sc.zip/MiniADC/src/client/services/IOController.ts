/**
 * An IO module that store and fetch game state data through window.localStorage.
 * Can be replaced by another IO module to handle the data IO.
 */
import { EventBus } from "~/client/events/EventBus";
import { capitalUpdatedEvt } from "~/client/events/EventDefinitions";

const STORAGE_KEYS = {
    firstRun: "_firstRun",
    capitalAmount: "_capitalAmount",
    producingStart: "_producingStart",
    producingEnd: "_producingEnd",
}

/**
 * Automatically call by setBusinessLastIncome, so don't need to be exported.
 * @param businessId 
 * @param endTime - If endTime got a value, it means that is a past producing end time from idle.
 */
const setProducingEnd = (businessId: string, endTime?:number): void => {
    if (!businessId) return;

    const theTime = (endTime === undefined) ? new Date().getTime() : endTime;
    window.localStorage.setItem(businessId.concat(STORAGE_KEYS.producingEnd), theTime.toString());
}

export const isTheFirstRun = (): boolean => {
    if (window.localStorage.getItem(STORAGE_KEYS.firstRun)) return false;
    else {
        window.localStorage.setItem(STORAGE_KEYS.firstRun, "anything");
        return true;
    }
}

export const getProducingEnd = (businessId: string): number => {
    if (!businessId) return -1;

    const endTimeStr = window.localStorage.getItem(businessId.concat(STORAGE_KEYS.producingEnd));
    return endTimeStr ? Number(endTimeStr) : -1;
}

export const setProducingStartTime = (businessId: string, startTime?:number): void => {
    if (!businessId) return;

    const theTime = (startTime === undefined) ? new Date().getTime() : startTime;
    window.localStorage.setItem(businessId.concat(STORAGE_KEYS.producingStart), theTime.toString());
}

export const getProducingStartTime = (businessId: string): number => {
    if (!businessId) return -1;

    const startTimeStr = window.localStorage.getItem(businessId.concat(STORAGE_KEYS.producingStart));
    return startTimeStr ? Number(startTimeStr) : -1;
}

export const setBusinessState = (businessId: string,
                                 investmentType: string,
                                 stateCondition: number): void => {
    if (!businessId || !investmentType) return;

    window.localStorage.setItem(businessId + "." + investmentType, stateCondition.toString());
}

export const getBusinessState = (businessId: string, investmentType: string): number => {
    if (!businessId || !investmentType) return -1;

    const conditionStr = window.localStorage.getItem(businessId + "." + investmentType);
    return conditionStr ? Number(conditionStr) : -1;
}

export const setBusinessIncome = (businessId: string, amount: number, endTime?:number): void => {
    if (!businessId) return;

    setIncome(amount);

    if (endTime === undefined) setProducingEnd(businessId);
    else setProducingEnd(businessId, endTime);
}

const setCapitalAmount = (amount: number): void => {
    window.localStorage.setItem(STORAGE_KEYS.capitalAmount, amount.toString());

    EventBus.getInstance().dispatchEvent(capitalUpdatedEvt(amount));
}

const setIncome = (amount: number): void => {
    setCapitalAmount(getCapitalAmount() + amount);
}

/**
 *  Should be only called once!
 * @param amount
 */
export const initCapital = (amount: number): void => {
    setCapitalAmount(amount);
}    

export const spend = (amount: number): void => {
    setCapitalAmount(getCapitalAmount() - amount);
}

export const getCapitalAmount = (): number => {
    const amountStr = window.localStorage.getItem(STORAGE_KEYS.capitalAmount);
    return (amountStr !== undefined) ? Number(amountStr) : -1;
}

export const resetGameData = (): void => {
    window.localStorage.clear();
}

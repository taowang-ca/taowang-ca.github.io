/**
 * We only do a console log here, but we could send the info to the server.
 * @param info 
 * @param source - Indicate where the info sent from.
 */
export const logInfo = (info: any, source?: string) => {
    if (source) console.log(`Info - source:${source}.`);
    console.log(info);
} 

/**
 * Log errors (string).
 * We only do a console log here, but we could send the error to the server.
 * @param error 
 * @param source - Indicate where the error sent from.
 */
export const logStrError = (error: string, source?: string) => {
    const msg = source ? `Error - source: ${source}; info: ${error}` : `Error - info: ${error}`;
    console.log(msg);
} 

/**
 * We want the errors from try..catch log to here.
 * We only do a console log here, but we could send the error to the server.
 * @param error 
 * @param source - Indicate where the error sent from.
 */
export const logCaughtError = (error: any, source?: string) => {
    if (source) console.log(`Error - source:${source}.`);
    console.log(error);
} 
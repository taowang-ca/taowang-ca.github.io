import { GameStateItem } from "~/client/types/UIDefinitions";
import { InvestmentType, BasicConditions, ProducingConditions } from "~/client/types/GameDataDefinitions";

/**
 * Contains all possible game state object.
 */
const gameStateLibs: Array<GameStateItem> = [
    { stateId: InvestmentType.business, stateValue: BasicConditions.unaffordable},  // 0
    { stateId: InvestmentType.business, stateValue: BasicConditions.affordable},    // 1
    { stateId: InvestmentType.business, stateValue: BasicConditions.acquired},      // 2
    { stateId: InvestmentType.manager, stateValue: BasicConditions.unaffordable},   // 3
    { stateId: InvestmentType.manager, stateValue: BasicConditions.affordable},     // 4
    { stateId: InvestmentType.manager, stateValue: BasicConditions.acquired},       // 5
    { stateId: InvestmentType.upgrade, stateValue: BasicConditions.unaffordable},   // 6
    { stateId: InvestmentType.upgrade, stateValue: BasicConditions.affordable},     // 7
    { stateId: InvestmentType.upgrade, stateValue: BasicConditions.acquired},       // 8
    { stateId: InvestmentType.produce, stateValue: ProducingConditions.active},     // 9
    { stateId: InvestmentType.produce, stateValue: ProducingConditions.idle}        // 10
];

/**
 * Contains a list of GameStateItem group, so the game does not need to re-create these groups
 * every time the game states changes.
 */
export const gameStateList: Array<Array<GameStateItem>> = [
    [gameStateLibs[0]],                         // 0
    [gameStateLibs[1]],                         // 1
    [gameStateLibs[2], gameStateLibs[3]],       // 2
    [gameStateLibs[2], gameStateLibs[4]],       // 3
    [gameStateLibs[2], gameStateLibs[5]],       // 4
    [gameStateLibs[2], gameStateLibs[6]],       // 5
    [gameStateLibs[2], gameStateLibs[7]],       // 6
    [gameStateLibs[2], gameStateLibs[8]],       // 7
    [gameStateLibs[2], gameStateLibs[9]],       // 8
    [gameStateLibs[2], gameStateLibs[10]]       // 9
]

import { IEvt } from "./IEventDispatcher";

export type CustomEvt<T> = {
    readonly type: string;
    readonly data?: T;
}

export const EVENT_PIXI = {
    clickOrPress: "pointerdown",
    pointerUp: "pointerup",
    pointerUpOutside: "pointerupoutside",
    pointerMove: "pointermove",
    hoverIn: "pointerover",
    hoverOut: "pointerout"
}

export const EVENT_CUSTOM = {
    clickOrPressUI: "EVT_CLICK_OR_PRESS_UI",
    setUILayout: "EVT_SET_UI_LAYOUT",
    capitalUpdated: "EVT_CAPITAL_UPDATED",
    startProducing: "EVT_START_PRODUCING",
    resumeProducing: "EVT_RESUME_PRODUCING",
    finishProducing: "EVT_FINISH_PRODUCING",
    investmentDone: "EVT_INVESTMENT_DONE"
}

export type EvtDataClickOrPressUI = { groupId: string; };
export const clickOrPressUIEvt = (data: EvtDataClickOrPressUI): IEvt => ({ type: EVENT_CUSTOM.clickOrPressUI, data });

export type EvtDataUILayout = { layoutIdx: number; resetGame: boolean };
export const setUILayoutEvt = (data: EvtDataUILayout): IEvt => ({ type: EVENT_CUSTOM.setUILayout, data });

export const capitalUpdatedEvt = (data: number): IEvt => ({ type: EVENT_CUSTOM.capitalUpdated, data });

export type EvtDataBusinessID = { businessId: string; };
export const startProducingEvt = (data: EvtDataBusinessID): IEvt => ({ type: EVENT_CUSTOM.startProducing, data });
export const finishProducingEvt = (data: EvtDataBusinessID): IEvt => ({ type: EVENT_CUSTOM.finishProducing, data });

export type EvtDataResumeProducing = EvtDataBusinessID & { progress: number; }; // progress - Milliseconds. 
export const resumeProducingEvt = (data: EvtDataResumeProducing): IEvt => ({ type: EVENT_CUSTOM.resumeProducing, data });

export type EvtDataInvestmentDone = EvtDataBusinessID & { investmentType: string };
export const investmentDoneEvt = (data: EvtDataInvestmentDone): IEvt => ({ type: EVENT_CUSTOM.investmentDone, data });

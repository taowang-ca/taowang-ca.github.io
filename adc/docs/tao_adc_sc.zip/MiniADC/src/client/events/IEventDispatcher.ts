export type IEvt = {
    readonly type: string,
    readonly data?: any,
} 

export type ListenerContainer = {
    [index: string]: Array<Listener>;
}

export type Listener = {
    readonly type: string;
    readonly callback: (data: any, type: string) => void;
    readonly scope: any;
}

export interface IEventDispatcher {
    addEventListener(type: string,
                    callback: (evt: any, ...args: Array<any>) => void,
                    scope: any): void;
    
    removeEventListener(type: string, callback: any, scope?: any): void;

    removeEventListenersByType(type: string): void;

    removeAllEventListeners(): void;

    hasEventListener(type: string): boolean;

    dispatchEvent(evt: IEvt): void;
}
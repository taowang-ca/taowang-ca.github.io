import {
    IEventDispatcher,
    ListenerContainer,
    Listener,
    IEvt
} from "client/events/IEventDispatcher";

export class EventBus implements IEventDispatcher{
    private static instance: EventBus;
    private listeners: ListenerContainer = {};

    /**
     * A private constructor is the key of implementating a singleton event bus.
     */
    private constructor() { }

    /**
     * EventBus.getInstance() is the only way to get the event bus's instance.
     */
    public static getInstance(): EventBus {
        if (EventBus.instance === undefined) {
            EventBus.instance = new EventBus();
        } 

        return EventBus.instance; 
    }

    /**
     * Use EventBus.getInstance().addEventListener to register a new event listener.
     * @param type
     * @param callback
     * @param scope 
     */
    public addEventListener(type: string,
                            callback: (evt: any, ...args: Array<any>) => void,
                            scope: any): void {
        if (this.listeners[type] === undefined) {
            this.listeners[type] = [];
        }

        const eventObj: Listener = {type, callback, scope};
        this.listeners[type].push(eventObj);
    }
    
    /**
     * Use EventBus.getInstance().removeEventListener to unregister an event listener.
     * @param type
     * @param callback
     * @param scope
     */
    public removeEventListener(type: string, callback: any, scope?: any): void {
        if (this.listeners.hasOwnProperty(type)) {
            if (callback !== undefined) {
                const updatedListeners: Array<Listener> = this.listeners[type].filter((listener: Listener) => {
                    return listener.callback !== callback || (scope !== undefined && scope !== listener.scope);
                });

                if (updatedListeners.length > 0) {
                    this.listeners[type] = updatedListeners;
                } else {
                    delete this.listeners[type];
                }
            }
        }
    }

    /**
     * Use EventBus.getInstance().removeEventListenersByType to unregister all event listeners of certain type.
     * @param type 
     */
    public removeEventListenersByType(type: string): void {
        if (this.listeners.hasOwnProperty(type)) {
            delete this.listeners[type];
        }    
    }

    /**
     * Use EventBus.getInstance().removeAllEventListeners to unregister all event listeners.
     */
    public removeAllEventListeners(): void {
        this.listeners = {};
    }
    
    /**
     * Use EventBus.getInstance().hasEventListener to see if there is any listener of certain type.
     * @param type
     */
    public hasEventListener(type: string): boolean {
        return this.listeners.hasOwnProperty(type);
    }

    /**
     * Use EventBus.getInstance().dispatchEvent to dispatch an event.
     * @param evt 
     */
    public dispatchEvent(evt: IEvt): void {
        const listeners = this.listeners[evt.type];
        if (listeners && listeners.length > 0) {
            for (const listener of listeners) {
                listener.callback.call(listener.scope, evt.data, evt.type);
            }
        }
    }
}
import { IStringTMap } from "~/client/utils/Generics";
import { DataFileInfo } from "./GameDataDefinitions";
import { RectangleDefinition, CircleDefinition } from "./ViewDefinition";

export type IStringPropertyMap = IStringTMap<any>;

export enum WrapperType {
    listItem = "listItem",
    fixedItem = "fixedItem",
}

export enum VisualElementType {
    label = "Label",
    sprite = "Sprite",
    rectangle = "Rectangle",
    circle = "Circle",
    graphics = "Graphics",
}

export enum ProgressIndicatorType {
    bar = 1,
    circle = 2,
}

export type GameStateItem = {
    stateId: string;
    stateValue: number;
}

/**
 * Use upper level notified condition list compare the conditions in the ResponseItem.
 * If all conditions met, the ResponseItem will response - apply responseProperties to the UI Element.
 */
export type ResponseItem = {
    readonly conditions: Array<GameStateItem>;
    readonly responseProperties: IStringPropertyMap;
}

/**
 * VisualElementData is the only needed data to created an VisualElement.
 * 
 * The container of the VisualElement (the VisualElementGroup) use elementType
 * to decide what type of the VisualElement should be created.
 * 
 * The initParameters is used for init the UIElement.
 * 
 * When game state changed, use the condition list in the new state as the value,
 * go through the responseList to find the matched ResponseItem.
 * There shouldn't be more than one match, if the match was found, it should response.
 */
export type VisualElementData = {
    readonly elementId: string;
    readonly elementType: VisualElementType;
    readonly initParameters: IStringPropertyMap;
    readonly initProperties: IStringPropertyMap;
    readonly responseList: Array<ResponseItem>;
}

/**
 * VisualElementGroupData is the data being used to create a VisualElementGroup.
 * 
 * The VisualElementGroup will go through elementDataList and create
 * all it's VisualElements.
 * 
 * Whenever the VisualElementGroup got the updated game state, it will go through
 * the elementDataList to find if a corresponding VisualElement
 * should response (apply corresponding responseProperties).
 */
export type VisualElementGroupData = {
    groupId: string;
    readonly groupType: string;
    readonly elementDataList: Array<VisualElementData>;
    readonly x: number;
    readonly y: number;
    interactive: boolean;
}

export type UIWrapperData = {
    readonly wrapperId: string;
    readonly wrapperType: string;
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
    gameUIGroups: Array<VisualElementGroupData>;
}

export type GameStageInfo = {
    readonly gameWidth: number;
    readonly gameHeight: number;
    readonly stageBgColor: string;
}

export type ProgressBarDefinition = {
    readonly backgroundStyle: RectangleDefinition;
    readonly barStyle: RectangleDefinition;
    readonly barX: number;
    readonly barY: number;
}

export type ProgressAmountDefinition = {
    readonly x: number;
    readonly y: number;
    readonly textStyle: Object;
    readonly title?: string;
}

export type ProgressIndicatorData = {
    readonly x: number;
    readonly y: number;
    readonly type: ProgressIndicatorType;
    readonly indicatorDef: CircleDefinition | ProgressBarDefinition;
    readonly amountDef: ProgressAmountDefinition;
}

export type GameUIData = DataFileInfo & {
    readonly stageInfo: GameStageInfo;
    readonly progressIndicator: ProgressIndicatorData;
    readonly wrapperGroups: Array<UIWrapperData>;
}
import { IStringTMap } from "~/client/utils/Generics";

export type IStringNumberMap = IStringTMap<number>;
export type IStringBooleanMap = IStringTMap<boolean>;
export type IStringStringMap = IStringTMap<string>;
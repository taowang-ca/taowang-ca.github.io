import { GameStateItem } from "./UIDefinitions";

export enum BasicConditions {
    unaffordable = 1,
    affordable,
    acquired,
}

export enum InvestmentType {
    business = "business",
    manager = "manager",
    upgrade = "upgrade",
    produce = "produce",
};

export enum ProducingConditions {
    idle = 10,
    active,
}

export type GameStateGroup = {
    groupType: InvestmentType;
    states: Array<GameStateItem>;
}

export type BusinessBasicData = {
    readonly businessId: string;
    readonly acquireCost: number;
    readonly productionCycle: number;    // Seconds.
    readonly profitPerCycle: number;
    readonly managerId: string;
    readonly managerWage: number;
    readonly upgradeCost: number;
    readonly upgradeProfitRate: number;
}

export type BusinessDataUI = {
    timerId: number;    // Being used for clear unfinished Timers when exit the game.
    producingStartTime: number;   // Milliseconds, Being used for the progress bar.
    businessStateListIdx: number;    // The current used idx of gameStateList in GameConstants.
    managerStateListIdx: number;     // The current used idx of gameStateList in GameConstants.
    updateStateListIdx: number;      // The current used idx of gameStateList in GameConstants.
}

export type BusinessData = BusinessBasicData & BusinessDataUI;

export type BusinessState = {
    ownerShip: BasicConditions;
    upgrade: BasicConditions;
    managing: BasicConditions;
    producing: ProducingConditions;
}

export type PlayerState = {
    capital: number;
}

export type DataFileInfo = {
    readonly gameName: string;
    readonly description: string;
    readonly Version: number;
    readonly initialCapital: number;
}

export type GameData = DataFileInfo & {
    readonly BusinessList: Array<BusinessBasicData>;
}

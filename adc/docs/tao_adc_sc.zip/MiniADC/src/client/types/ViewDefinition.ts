import { Graphics, Sprite, Text } from "pixi.js"

export type PiXiElement = Graphics | Sprite | Text;

export type FillStyleDefinition = {
    color?: number;
    alpha?: number;
}

export type LineStyleDefinition = FillStyleDefinition & {
    width?: number;
}

export type ShapeDefinition = {
    lineStyle?: LineStyleDefinition | null;
    fillStyle?: FillStyleDefinition | null;
}

export type RectangleDefinition = ShapeDefinition & {
    width: number;
    height: number;
    radius?: number;
}

export type CircleDefinition = ShapeDefinition & {
    radius: number;
}

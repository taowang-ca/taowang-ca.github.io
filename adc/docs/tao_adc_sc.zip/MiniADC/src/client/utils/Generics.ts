export type IStringTMap<T> = { [key: string]: T; }
export type IStringNumberMap = IStringTMap<number>;
export type IStringBooleanMap = IStringTMap<boolean>;
export type IStringStringMap = IStringTMap<string>;

/**
 * Check if an object has the key (property).
 * @param obj 
 * @param key - "keyof any" is short for "string | number | symbol".
 *              An object key can be any of those types.
 */
export const hasKey = <O>(obj: O, key: keyof any): key is keyof O => {
    return key in obj
}

/**
 * Set an object's property to a value safely.
 * @param obj 
 * @param property - "keyof any" is short for "string | number | symbol".
 *                   The property will only be available at runtime.
 * @param value - The value will only be available at runtime, we need to check if it's undefined.
 */
export const setPropertyValue = <O>(obj: O, property: keyof any, value: any): void => {
    if (hasKey(obj, property) && value !== undefined) obj[property] = value;
}

/**
 * Set an object's property's deeperProperty (obj[property][propertyDeeper]) to a value safely.
 * @param obj 
 * @param property - "keyof any" is short for "string | number | symbol".
 *                   The property will only be available at runtime.
 * @param value - The value will only be available at runtime, we need to check if it's undefined.
 */
export const setDeeperPropertyValue = <O>(obj: O, property: keyof any, deeperProperty: keyof any, value: any): void => {
    if (hasKey(obj, property)) {
        if (hasKey(obj[property], deeperProperty) && value !== undefined) obj[property][deeperProperty] = value;
    } 
}

/**
 * Get an object's property's value.
 * @param obj 
 * @param property - "keyof any" is short for "string | number | symbol".
 *                   The property will only be available at runtime.
 */
export const getPropertyValue = <O>(obj: O, property: keyof any): any => {
    if (hasKey(obj, property)) return obj[property];
}
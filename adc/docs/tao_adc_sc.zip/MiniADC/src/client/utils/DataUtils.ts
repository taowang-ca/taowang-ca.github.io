import { GameStateItem, UIWrapperData, VisualElementData } from "~/client/types/UIDefinitions";
import { BusinessBasicData, InvestmentType } from "~/client/types/GameDataDefinitions";
import { setPropertyValue } from "./Generics";
import { easyReadNumber } from "./StringUtils";

const ASSET_EXT = ".png";
const SPRITE_PROP =  "name";
const TEXT_PROP =  "text";

enum DefaultElementId {
    businessIcon = "businessIcon",
    businessCost = "businessCost",
    managerIcon = "managerIcon",
    managerWage = "managerWage",
    upgradeCost = "upgradeCost",
}

export const sortGameStateItem = (a: GameStateItem, b: GameStateItem): number => {
    return (a.stateId > b.stateId) ? 1 : (a.stateId < b.stateId) ? -1 : 0;
}

export const matchStateItem = (a: GameStateItem, b: GameStateItem): boolean => {
    return a.stateId === b.stateId && a.stateValue === b.stateValue;
}

export const sortBusinessByCost = (a: BusinessBasicData, b: BusinessBasicData): number => {
    return (a.acquireCost > b.acquireCost) ? 1 : (a.acquireCost < b.acquireCost) ? -1 : 0;
}

export const applyBusinessDataToWrapper = (wrapper: UIWrapperData, business: BusinessBasicData): void => {
    if (!wrapper || !business || wrapper.wrapperId === undefined || wrapper.wrapperId !== "businessItem") return;
    if (!wrapper.gameUIGroups || !(wrapper.gameUIGroups instanceof Array)) return;
    
    wrapper.gameUIGroups = wrapper.gameUIGroups.map(a => ({...a}));
    wrapper.gameUIGroups.forEach(group => {
        if (group.groupId !== undefined && group.elementDataList != undefined) {
            switch (group.groupId) {
                case InvestmentType.business:
                    group.groupId = business.businessId + "." + InvestmentType.business;
                    setElementParameter(group.elementDataList, DefaultElementId.businessIcon, SPRITE_PROP, business.businessId + ASSET_EXT);
                    setElementParameter(group.elementDataList, DefaultElementId.businessCost, TEXT_PROP, easyReadNumber(business.acquireCost));
                    break;
            
                case InvestmentType.manager:
                    group.groupId = business.businessId + "." + InvestmentType.manager;
                    setElementParameter(group.elementDataList, DefaultElementId.managerIcon, SPRITE_PROP, business.managerId + ASSET_EXT);
                    setElementParameter(group.elementDataList, DefaultElementId.managerWage, TEXT_PROP, easyReadNumber(business.managerWage));
                    break;
    
                case InvestmentType.upgrade:
                    group.groupId = business.businessId + "." + InvestmentType.upgrade;
                    setElementParameter(group.elementDataList, DefaultElementId.upgradeCost, TEXT_PROP, easyReadNumber(business.upgradeCost));
                    break;
                    
                default:
                    break;
            }
        }
    });
}

/**
 * Compare two sorted GameState (an array of GameStateItem) to see if they are match.
 * For the game, we don't need the GameStateItems in two GameStates has the same order to say they are match.
 * This function will check match by order, it could sort the GameStateItems in two GameStates first then check the match,
 * but it does not do the sorting, instead it needs the two GameState parameters to be sorted before passed in for a better performance in Game.
 * Therefore, before call this function, ALWAYS make sure the GameState parameters have been sorted by the sortGameStateItem function.
 * @param a 
 * @param b 
 */
export const matchSortedGameState = (a: Array<GameStateItem>, b: Array<GameStateItem>): boolean => {
    return a.length === b.length && a.every((value, index) => matchStateItem(value, b[index]));
}

/**
 * Compare two unsorted GameState (an array of GameStateItem) to see if they are match.
 * This function will sort the GameStateItems in two GameState parameters first then check the match.
 * Sort GameStateItems for every match check is not very efficient,
 * so use matchSortedGameState function instead this function when possible.
 * @param a 
 * @param b 
 */
export const matchUnsortedGameState = (a: Array<GameStateItem>, b: Array<GameStateItem>): boolean => {
    return  a.length === b.length &&
            a.sort(sortGameStateItem).every((value, index) => matchStateItem(value, b.sort(sortGameStateItem)[index]));
}

const setElementParameter = (elements: Array<VisualElementData>,
                            elementId: string,
                            ParameterKey: string,
                            value: string): void => {
    if (!elements || !(elements instanceof Array)) return; 

    for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        if (element.elementId === elementId) {
            if (element.initParameters) {
                for (const key in element.initParameters) {
                    if (key === ParameterKey) setPropertyValue(element.initParameters, key, value);
                }    
            }
        }
    }
}

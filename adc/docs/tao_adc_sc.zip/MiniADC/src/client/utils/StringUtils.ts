export const strNumberWithCommas = (str: string): string => {
    // return str.replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ","); // "lookbehind" is not supported by Safari!
    var parts = str.split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}

export const numberWithCommas = (num: number): string => {
    return strNumberWithCommas(num.toString());
}

export const easyReadNumber = (num: number): string => {
    const abs = Math.abs(num);

    return (abs >= 1.0e+12) ? 
    +strNumberWithCommas((num / 1.0e+12).toFixed(3)) + " Trillion" :
    (abs >= 1.0e+9) ?
    +strNumberWithCommas((num / 1.0e+9).toFixed(3)) + " Billion" :
    (abs >= 1.0e+6) ?
    +strNumberWithCommas((num / 1.0e+6).toFixed(3)) + " Million" :
    strNumberWithCommas(num.toString());
}
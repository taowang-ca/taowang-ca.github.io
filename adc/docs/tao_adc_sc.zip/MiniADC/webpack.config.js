const path = require('path');

module.exports = {
  context: path.resolve(__dirname, 'src/'),
  entry: './main.ts',
  output: {
    filename: 'adc.js',
    path: path.resolve(__dirname, './dist'),
  },
  resolve: {
    extensions: ['.ts', '.js'],
    alias: {
      client: path.resolve(__dirname, 'src/client/'),
      "./client": path.resolve(__dirname, 'src/client/'),
      "~/client": path.resolve(__dirname, 'src/client/')
    }
  },
  module: {
    rules: [
      {
        test: /\.ts$/,
        loader: 'ts-loader'
      }
    ]
  },
  devtool: 'source-map',
};
